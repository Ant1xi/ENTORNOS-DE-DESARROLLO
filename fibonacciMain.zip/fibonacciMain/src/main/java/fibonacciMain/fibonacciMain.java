package fibonacciMain;

import fibonacci.fibonacci;

public class fibonacciMain {
	public static void main(String[] args) {
		fibonacci.SucesionFibonacci(10);
	}
}